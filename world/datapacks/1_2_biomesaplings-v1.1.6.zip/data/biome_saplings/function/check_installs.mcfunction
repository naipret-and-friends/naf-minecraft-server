

scoreboard players set blooming_biosphere saplings_storage 0
execute store result score blooming_biosphere saplings_storage run function blooming_biosphere:installed


execute if data storage vanilla_refresh_config:config config{load_message:1} if score blooming_biosphere saplings_storage matches 1 run tellraw @a [{"translate": "Successfully loaded ","color": "gray"},{"translate": "Blooming Biosphere Biome Saplings v1.1.6","color": "green"}]
execute if data storage vanilla_refresh_config:config config{load_message:1} unless score blooming_biosphere saplings_storage matches 1 run tellraw @a [{"translate": "Successfully loaded ","color": "gray"},{"translate": "Terralith Biome Saplings v1.1.6","color": "green"}]
