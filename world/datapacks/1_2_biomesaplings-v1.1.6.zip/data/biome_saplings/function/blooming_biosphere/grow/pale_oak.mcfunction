setblock ~ ~ ~ air


execute store result score number saplings_randomizer run random value 1..6

execute if score number saplings_randomizer matches 1..5 run place feature blooming_biosphere:pale_garden/trees/thin
execute if score number saplings_randomizer matches 6 run place feature blooming_biosphere:pale_garden/trees/willow

execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/pale_oak_sapling
kill @s