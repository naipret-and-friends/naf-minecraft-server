setblock ~ ~ ~ air

place feature blooming_biosphere:birch_forest/trees/birch

execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/birch_sapling
kill @s