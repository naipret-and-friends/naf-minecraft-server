setblock ~ ~ ~ air


execute store result score number saplings_randomizer run random value 1..3

execute if score number saplings_randomizer matches 1 run place feature blooming_biosphere:oak_forest/trees/standard_birch
execute if score number saplings_randomizer matches 2..3 run place feature blooming_biosphere:autumnal_forest/trees/branch_birch


execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/birch_sapling
kill @s