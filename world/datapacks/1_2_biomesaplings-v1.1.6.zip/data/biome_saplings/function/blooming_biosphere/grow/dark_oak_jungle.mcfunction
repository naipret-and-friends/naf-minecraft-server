setblock ~ ~ ~ air
place feature blooming_biosphere:bamboo_jungle/trees/fancy_dark_oak
execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/dark_oak_sapling
kill @s