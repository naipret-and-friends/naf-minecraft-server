setblock ~ ~ ~ air
place feature blooming_biosphere:taiga/trees/autumnal_oak
execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/oak_sapling
kill @s