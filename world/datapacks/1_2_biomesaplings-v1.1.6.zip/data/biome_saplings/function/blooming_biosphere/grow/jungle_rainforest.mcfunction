setblock ~ ~ ~ air
place feature blooming_biosphere:jungle/trees/rainforest_medium
execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/jungle_sapling
kill @s