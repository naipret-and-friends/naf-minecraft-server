setblock ~ ~ ~ air
place feature blooming_biosphere:oak_forest/trees/standard_birch
execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/birch_sapling
kill @s