setblock ~ ~ ~ air
place feature blooming_biosphere:wooded_badlands/trees/dark_oak
execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/dark_oak_sapling
kill @s