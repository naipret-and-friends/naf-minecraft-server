

execute store result score number saplings_randomizer run random value 1..4

execute if score number saplings_randomizer matches 1 run place feature terralith:highlands/forest/mid/pine_mid
execute if score number saplings_randomizer matches 2 run place feature terralith:highlands/forest/mid/trees_mid
execute if score number saplings_randomizer matches 3 run place feature terralith:highlands/forest/mid/spruce_mid_m
execute if score number saplings_randomizer matches 4 run place feature terralith:highlands/forest/small/trees_small

execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/spruce_sapling

kill @s