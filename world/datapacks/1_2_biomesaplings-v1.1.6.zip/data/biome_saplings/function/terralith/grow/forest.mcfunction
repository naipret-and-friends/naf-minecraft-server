setblock ~ ~ ~ air
execute if predicate biome_saplings:chance/10_percent run place feature terralith:forest/vanilla/fancy_oak
execute if block ~ ~ ~ air run place feature terralith:forest/vanilla/oak
execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/oak_sapling
kill @s