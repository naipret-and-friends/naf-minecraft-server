#> from: biome_saplings:terralith/saplings/[SAPLING]

# simple tree growth for non randomized trees

    # this function takes in a macro input for
    # - feature file path
    # - sapling type
    # - any additional command

#

setblock ~ ~ ~ air
$place feature $(feature)
$execute if block ~ ~ ~ air run loot spawn ~ ~ ~ loot biome_saplings:drop/$(sapling)_sapling
kill @s

$$(command1)
$$(command2)