
execute if entity @s[tag=!saplings_sapling_placed] run function biome_saplings:other/placed

execute if predicate biome_saplings:chance/50_percent if score saplings_particle saplings_count matches 1 run particle effect ~ ~-.5 ~ 0 0 0 0 1 normal @a[distance=..32]

execute if block ~ ~ ~ acacia_sapling[stage=1] run scoreboard players add @s saplings_count 500
execute if block ~ ~ ~ acacia_sapling[stage=1] run setblock ~ ~ ~ acacia_sapling[stage=0]


execute if score @s saplings_count matches 3000.. run function biome_saplings:terralith/grow/a_simple_tree {feature:"terralith:jungle/amethyst/tree_2x2",sapling:"acacia",command1:"playsound minecraft:block.vine.step ambient @a[distance=..32] ~ ~ ~ 2 .75",command2:"return 1"}



execute unless block ~ ~ ~ acacia_sapling run kill @s