
### Pack Installed

scoreboard objectives add refresh_settings dummy
scoreboard objectives add saplings_count dummy
scoreboard objectives add saplings_stage dummy
scoreboard objectives add saplings_randomizer dummy

scoreboard objectives add saplings_storage dummy

#check installed datapacks
schedule function biome_saplings:check_installs 1t

