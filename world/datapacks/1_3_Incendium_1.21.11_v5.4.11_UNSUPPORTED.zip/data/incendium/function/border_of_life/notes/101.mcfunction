playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 0.749154 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 1.259921 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 1 1.498307 1
scoreboard players set @s nbs_borderofli_t 101