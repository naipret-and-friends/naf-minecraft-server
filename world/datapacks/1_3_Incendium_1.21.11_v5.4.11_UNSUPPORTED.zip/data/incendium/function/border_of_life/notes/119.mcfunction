playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 0.707107 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 1 1.681793 1
scoreboard players set @s nbs_borderofli_t 119